# Multi-Platform CI/CD Agent

You help teams create and trigger mobile CI/CD pipelines for **iOS, Android, Flutter, and React Native** projects.

## Platform detection

Before creating a pipeline or bootstrapping a repo, detect the project type:

```bash
./scripts/detect_project_platform.sh
```

Supported platforms:
- **ios** — `.xcodeproj` / `.xcworkspace`
- **android** — Gradle project (`android/` or root `settings.gradle`)
- **flutter** — `pubspec.yaml` with Flutter SDK
- **react-native** — `package.json` with `react-native`

Set `CICD_PLATFORM=auto` (default) to auto-detect in CI. Override with `CICD_PLATFORM` and `CICD_BUILD_TARGET` when needed.

## Modes

### 1. Create Pipeline

Follow `.github/prompts/create-pipeline.prompt.md`.

Uses `.github/pipeline-templates/mobile-ci-workflow.template.yml` — a single template that auto-detects platform at runtime.

### 2. Trigger Build

Follow `.github/prompts/trigger-build.prompt.md`.

Uses `scripts/trigger_existing_workflow.sh` — works with any GitHub Actions workflow URL.

## Bootstrap (new repos)

```bash
./scripts/bootstrap_new_repo.sh <target-repo-path> [app-identifier]
```

Copies agent files, scripts, Fastlane lanes, and platform-aware defaults.

## Key files

| File | Purpose |
|------|---------|
| `scripts/detect_project_platform.sh` | Auto-detect platform and CI defaults |
| `scripts/bootstrap_new_repo.sh` | Copy starter kit into a target repo |
| `.github/cicd.config.yml` | Agent configuration and required secrets per platform |
| `.github/cicd.env.config.yml` | Default GitHub Variables |
| `fastlane/Fastfile` | Build lanes for all platforms |

## Platform notes

- **iOS** builds run on `macos-latest` (or custom runner label in template).
- **Android** builds run on `ubuntu-latest`.
- **Flutter / React Native** default to **Android** CI on Ubuntu. Set `CICD_BUILD_TARGET=ios` for iOS builds (requires macOS runner).

## Required setup

See `CICD_HOT_RUN_SETUP.md` for the full onboarding checklist.
