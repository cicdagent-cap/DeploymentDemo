# Agent Handoff Contract

This document defines the **machine-readable contract** between the CI/CD agent and other agents in your system.

---

## Agent identity

```yaml
agent_id: cicd
name: CI/CD Agent
version: 1.0.0
definition: agent/CICD.agent.md
```

---

## Capabilities

### `detect-platform`

Detects the mobile platform in a repository.

**Input:**

```yaml
repo_path: /absolute/path/to/repo
format: json   # human | env | github | json
```

**Command:**

```bash
./scripts/detect_project_platform.sh --repo <repo_path> --format json
```

**Output (success):**

```json
{
  "platform": "ios",
  "runner": "macos-latest",
  "fastlane_platform": "ios",
  "project_file": "MyApp.xcodeproj",
  "default_scheme": "MyApp",
  "app_identifier": "com.example.myapp"
}
```

**Output (failure):** exit code `1`, stderr message.

---

### `create-pipeline`

Generates a GitHub Actions workflow file.

**Input schema** (`requests/pipeline-request.yml`):

```yaml
pipeline:
  name: string          # required — workflow display name
  output_file: string   # required — e.g. .github/workflows/ci.yml

platform:
  detection: auto | ios | android | flutter | react-native
  build_target: android | ios   # flutter / react-native only

github_actions:
  runner_label: string  # e.g. macos-latest
  default_branch: string

presets:
  default: Debug-CICD
  options: [Debug-CICD, Release-CICD]
```

**Processing steps:**

1. Run `detect-platform` (unless platform overridden)
2. Read `templates/mobile-ci-workflow.template.yml`
3. Replace placeholders: `__PIPELINE_NAME__`, `__RUNNER_LABEL__`, `__DEFAULT_PROJECT_FILE__`, `__DEFAULT_SCHEME__`
4. Write file to `output_file`

**Output:**

```yaml
status: success
workflow_file: .github/workflows/ci.yml
platform: ios
missing_configuration:
  variables: [CICD_PROJECT_FILE, CICD_DEFAULT_SCHEME]
  secrets: [TEAM_WEBHOOK_URL, MATCH_PASSWORD]
```

---

### `trigger-build`

Dispatches a GitHub Actions workflow.

**Input schema** (`requests/trigger-build-request.yml`):

```yaml
target:
  workflow_url: string   # required — full GitHub Actions workflow URL
  branch_name: string    # required — git ref to run against

workflow_inputs:         # optional — key=value pairs passed to workflow
  preset: Debug-CICD
  Release_Notes: string

notification:
  provider: teams | slack | generic
  webhook_secret_or_env_name: TEAM_WEBHOOK_URL
```

**Processing steps:**

1. Run `inspect_workflow_inputs.sh <workflow_url> <branch>`
2. Merge `workflow_inputs` with discovered required inputs
3. Run `trigger_existing_workflow.sh <url> <branch> key=value ...`

**Output (success):**

```yaml
status: triggered
run_url: https://github.com/org/repo/actions/runs/123456
notifications: enabled | disabled
```

**Output (skipped — duplicate run):**

```yaml
status: skipped
reason: build_already_in_progress
```

---

## Orchestrator integration example

```yaml
# orchestrator.routes.yml
routes:
  - when: intent == "deploy_mobile_app"
  - then:
      - agent: cicd
        capability: detect-platform
        input: { repo_path: "${TARGET_REPO}" }
      - agent: cicd
        capability: trigger-build
        input:
          target:
            workflow_url: "${CI_WORKFLOW_URL}"
            branch_name: "${GIT_BRANCH}"
          workflow_inputs:
            preset: Release-CICD
```

---

## Environment variable summary (quick reference)

### Common

| Key | Scope | Required |
|-----|-------|----------|
| `TEAM_WEBHOOK_URL` | secret | Yes (notifications) |
| `CICD_CHAT_PROVIDER` | variable | Yes |
| `CICD_PLATFORM` | variable | Yes (`auto`) |

### iOS

`CICD_PROJECT_FILE`, `CICD_DEFAULT_SCHEME`, `CICD_DEFAULT_CONFIGURATION`, `CICD_TEST_DESTINATION`, `FASTLANE_BUNDLE_IDENTIFIER`, `FASTLANE_TEAM_ID`, `FASTLANE_ITC_TEAM_ID`, `MATCH_GIT_URL`, `MATCH_PASSWORD`, `MATCH_GIT_BASIC_AUTHORIZATION`, `APP_STORE_CONNECT_API_KEY`

### Android

`CICD_GRADLE_DIR`, `ANDROID_KEYSTORE_BASE64`, `ANDROID_KEYSTORE_PASSWORD`, `ANDROID_KEY_ALIAS`, `ANDROID_KEY_PASSWORD`

### Flutter / React Native

`CICD_BUILD_TARGET`, `CICD_GRADLE_DIR`, `CICD_NODE_VERSION` (RN only)

Full details: [INTEGRATION.md](../INTEGRATION.md#5-required-keys-and-secrets)

---

## Error codes

| Code | Meaning |
|------|---------|
| `PLATFORM_UNKNOWN` | `detect-platform` could not identify project type |
| `GH_NOT_AUTHENTICATED` | `gh auth login` required |
| `MISSING_ENV` | `TEAM_WEBHOOK_URL` not configured |
| `DUPLICATE_RUN` | Build already in progress (not an error — intentional guard) |
| `INVALID_WORKFLOW_URL` | Workflow URL parsing failed |
