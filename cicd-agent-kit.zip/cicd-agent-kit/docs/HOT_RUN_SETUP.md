# CI/CD Hot Run Setup (Multi-Platform)

Use this as the first step whenever onboarding a new mobile repository (iOS, Android, Flutter, or React Native) to this CI/CD agent.

## Goal

Make pipeline creation and build triggering work on day 0 with minimum rework across all supported platforms.

## Supported platforms

| Platform | Detection signal | Default CI runner |
|----------|------------------|-------------------|
| iOS | `.xcodeproj` / `.xcworkspace` | macOS |
| Android | `android/` Gradle or root Gradle | Ubuntu |
| Flutter | `pubspec.yaml` with Flutter SDK | Ubuntu (Android target) |
| React Native | `package.json` with `react-native` | Ubuntu (Android target) |

For Flutter and React Native, set `CICD_BUILD_TARGET=ios` to build iOS on macOS.

## Hot Run Order (Run In This Sequence)

1. Run the bootstrap script to copy and auto-map CI/CD files.
2. Verify platform detection.
3. Configure local environment template and local env file.
4. Set project-specific defaults (scheme, bundle id, gradle dir, build target).
5. Configure GitHub Actions Variables and Secrets for your platform.
6. Validate with one manual trigger.
7. Start normal use of the CICD agent modes.

## 0) Recommended One-Command Bootstrap

Run from the CICD template repo:

```bash
./scripts/bootstrap_new_repo.sh <target-repo-path> [app-identifier]
```

Examples:

```bash
./scripts/bootstrap_new_repo.sh /Users/you/projects/MyiOSApp com.example.myiosapp
./scripts/bootstrap_new_repo.sh /Users/you/projects/MyAndroidApp
./scripts/bootstrap_new_repo.sh /Users/you/projects/MyFlutterApp
```

This command:

- copies the required starter files
- auto-detects platform (ios / android / flutter / react-native)
- rewrites copied defaults in CI/CD config and Fastlane files

## 0b) Verify detection

```bash
cd <target-repo>
./scripts/detect_project_platform.sh
```

## 1) Starter Files Checklist

Required folders/files:

- .github/agents/CICD.agent.md
- .github/prompts/create-pipeline.prompt.md
- .github/prompts/trigger-build.prompt.md
- .github/pipeline-templates/mobile-ci-workflow.template.yml
- .github/cicd.config.yml
- .github/cicd.env.config.yml
- .github/pipeline-request.yml
- .github/trigger-build-request.yml
- .github/config-overrides/config_overrides.json
- scripts/detect_project_platform.sh
- scripts/inspect_workflow_inputs.sh
- scripts/trigger_existing_workflow.sh
- scripts/notify.sh
- fastlane/Fastfile
- Gemfile
- .env.example

## 2) Local Environment Bootstrap

Run from repo root:

```bash
cp .env.example .notification.local.env
```

Fill `.notification.local.env` with real local values (never commit this file):

- TEAM_WEBHOOK_URL
- CICD_CHAT_PROVIDER (teams, slack, generic)
- CICD_PLATFORM (auto, or force ios/android/flutter/react-native)
- CICD_BUILD_TARGET (android or ios — for Flutter / React Native)

### iOS-specific

- FASTLANE_TEAM_ID, FASTLANE_ITC_TEAM_ID
- FASTLANE_BUNDLE_IDENTIFIER
- MATCH_GIT_URL, MATCH_PASSWORD, MATCH_GIT_BASIC_AUTHORIZATION
- APP_STORE_CONNECT_API_KEY

### Android-specific

- ANDROID_KEYSTORE_BASE64, ANDROID_KEYSTORE_PASSWORD
- ANDROID_KEY_ALIAS, ANDROID_KEY_PASSWORD

### Optional

- FIREBASE_APP_ID, FIREBASE_CLI_TOKEN (distribution)

## 3) Project Mapping (Must Update)

### iOS

- CICD_PROJECT_FILE → `<YourProject>.xcodeproj`
- CICD_DEFAULT_SCHEME → `<YourScheme>`
- CICD_DEFAULT_CONFIGURATION → Debug
- CICD_TEST_DESTINATION → `platform=iOS Simulator,name=<Device>`
- FASTLANE_BUNDLE_IDENTIFIER → `<your.bundle.id>`

### Android

- CICD_GRADLE_DIR → `android` (or `.` for root Gradle projects)
- FASTLANE_BUNDLE_IDENTIFIER / applicationId → `<your.package.name>`

### Flutter / React Native

- CICD_BUILD_TARGET → `android` (default) or `ios`
- CICD_GRADLE_DIR → `android`
- CICD_NODE_VERSION → `20` (React Native)

Update in:

- .github/cicd.env.config.yml
- .env.example
- fastlane/Fastfile fallback defaults
- fastlane/Appfile (iOS bundle id)

## 4) GitHub Actions Setup (Repo Settings)

Path: Settings → Secrets and variables → Actions

### All platforms

Variables: `CICD_PLATFORM` (auto), `CICD_CHAT_PROVIDER`
Secrets: `TEAM_WEBHOOK_URL`

### iOS variables & secrets

See section 3 iOS mapping plus Match and App Store Connect secrets.

### Android variables & secrets

- `CICD_GRADLE_DIR`
- Android keystore secrets for release builds

## 5) Validation Commands

Detect platform:

```bash
./scripts/detect_project_platform.sh
```

Check workflow inputs:

```bash
./scripts/inspect_workflow_inputs.sh <workflow-url> <branch>
```

Trigger workflow:

```bash
./scripts/trigger_existing_workflow.sh <workflow-url> <branch> preset=Debug-CICD
```

Expected output contains:

- Environment: Configured via local file or GitHub
- Build triggered successfully
- Run URL

## 6) Operational Rule

For every new project, run this Hot Run setup before using:

- Create Pipeline mode
- Trigger Build mode

This prevents most first-run failures (platform mismatch, missing secrets, and signing issues).
