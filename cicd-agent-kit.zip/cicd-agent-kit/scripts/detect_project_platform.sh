#!/usr/bin/env bash
set -euo pipefail

# Detect mobile project platform and emit CI/CD defaults.
# Supports: ios, android, flutter, react-native

REPO_ROOT="$(pwd)"
FORMAT="human"

usage() {
  cat <<'EOF'
Usage:
  ./scripts/detect_project_platform.sh [--repo <path>] [--format human|env|github|json]

Formats:
  human   Print a readable summary (default)
  env     Print shell export statements
  github  Append platform + runner outputs to GITHUB_OUTPUT
  json    Print a single JSON object
EOF
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --repo)
      REPO_ROOT="${2:-}"
      shift 2
      ;;
    --format)
      FORMAT="${2:-human}"
      shift 2
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      echo "Unknown argument: $1" >&2
      usage
      exit 1
      ;;
  esac
done

if [[ ! -d "$REPO_ROOT" ]]; then
  echo "Repo path does not exist: $REPO_ROOT" >&2
  exit 1
fi

cd "$REPO_ROOT"

# Honor explicit overrides from env / GitHub Variables.
EXPLICIT_PLATFORM="${CICD_PLATFORM:-}"
EXPLICIT_BUILD_TARGET="${CICD_BUILD_TARGET:-}"

is_flutter_project() {
  [[ -f "$REPO_ROOT/pubspec.yaml" ]] && grep -qE 'sdk:\s*flutter' "$REPO_ROOT/pubspec.yaml"
}

is_react_native_project() {
  [[ -f "$REPO_ROOT/package.json" ]] && grep -qE '"react-native"\s*:' "$REPO_ROOT/package.json"
}

has_ios_project() {
  find "$REPO_ROOT" -maxdepth 2 \( -name '*.xcodeproj' -o -name '*.xcworkspace' \) -print -quit | grep -q .
}

has_android_project() {
  [[ -d "$REPO_ROOT/android" && ( -f "$REPO_ROOT/android/build.gradle" || -f "$REPO_ROOT/android/build.gradle.kts" ) ]] \
    || [[ -f "$REPO_ROOT/settings.gradle" || -f "$REPO_ROOT/settings.gradle.kts" || -f "$REPO_ROOT/build.gradle" || -f "$REPO_ROOT/build.gradle.kts" ]]
}

find_xcode_project() {
  find "$REPO_ROOT" -maxdepth 2 -type d -name '*.xcodeproj' | head -n1
}

find_xcworkspace() {
  find "$REPO_ROOT" -maxdepth 2 -type d -name '*.xcworkspace' | head -n1
}

gradle_dir() {
  if [[ -d "$REPO_ROOT/android" ]]; then
    echo "android"
  else
    echo "."
  fi
}

read_application_id() {
  local gradle_root="$1"
  local gradle_file=""

  for candidate in \
    "$REPO_ROOT/$gradle_root/app/build.gradle" \
    "$REPO_ROOT/$gradle_root/app/build.gradle.kts" \
    "$REPO_ROOT/$gradle_root/build.gradle" \
    "$REPO_ROOT/$gradle_root/build.gradle.kts"; do
    if [[ -f "$candidate" ]]; then
      gradle_file="$candidate"
      break
    fi
  done

  if [[ -z "$gradle_file" ]]; then
    echo "com.example.app"
    return
  fi

  local app_id
  app_id="$(grep -E 'applicationId\s*[=:]' "$gradle_file" | head -n1 | sed -E 's/.*applicationId\s*[=:]\s*["'\'']([^"'\'']+)["'\''].*/\1/' || true)"
  if [[ -n "$app_id" ]]; then
    echo "$app_id"
  else
    echo "com.example.app"
  fi
}

read_pubspec_name() {
  if [[ -f "$REPO_ROOT/pubspec.yaml" ]]; then
    grep -E '^name:\s*' "$REPO_ROOT/pubspec.yaml" | head -n1 | awk '{print $2}' | tr -d '"'\'''
  else
    echo "app"
  fi
}

read_package_name() {
  if [[ -f "$REPO_ROOT/package.json" ]]; then
    node -e "try { const p=require('$REPO_ROOT/package.json'); process.stdout.write(p.name || 'app'); } catch { process.stdout.write('app'); }" 2>/dev/null \
      || grep -E '"name"\s*:' "$REPO_ROOT/package.json" | head -n1 | sed -E 's/.*"name"\s*:\s*"([^"]+)".*/\1/'
  else
    echo "app"
  fi
}

CICD_PLATFORM="unknown"
CICD_BUILD_TARGET=""
CICD_RUNNER="ubuntu-latest"
CICD_FASTLANE_PLATFORM=""
CICD_PROJECT_FILE=""
CICD_DEFAULT_SCHEME=""
CICD_DEFAULT_CONFIGURATION="Debug"
CICD_TEST_DESTINATION=""
CICD_GRADLE_DIR=""
CICD_GRADLE_TASK="assembleDebug"
CICD_APP_IDENTIFIER="com.example.app"
CICD_NODE_VERSION="20"

if [[ -n "$EXPLICIT_PLATFORM" && "$EXPLICIT_PLATFORM" != "auto" ]]; then
  CICD_PLATFORM="$EXPLICIT_PLATFORM"
elif is_flutter_project; then
  CICD_PLATFORM="flutter"
elif is_react_native_project; then
  CICD_PLATFORM="react-native"
elif has_ios_project; then
  CICD_PLATFORM="ios"
elif has_android_project; then
  CICD_PLATFORM="android"
fi

if [[ "$CICD_PLATFORM" == "flutter" ]]; then
  CICD_BUILD_TARGET="${EXPLICIT_BUILD_TARGET:-android}"
  CICD_APP_IDENTIFIER="$(read_application_id "$(gradle_dir)")"
  CICD_DEFAULT_SCHEME="$(read_pubspec_name)"
  CICD_GRADLE_DIR="$(gradle_dir)"
fi

if [[ "$CICD_PLATFORM" == "react-native" ]]; then
  CICD_BUILD_TARGET="${EXPLICIT_BUILD_TARGET:-android}"
  CICD_APP_IDENTIFIER="$(read_application_id "$(gradle_dir)")"
  CICD_DEFAULT_SCHEME="$(read_package_name)"
  CICD_GRADLE_DIR="$(gradle_dir)"
fi

if [[ "$CICD_PLATFORM" == "ios" ]]; then
  PROJECT_PATH="$(find_xcode_project)"
  WORKSPACE_PATH="$(find_xcworkspace)"
  if [[ -n "$PROJECT_PATH" ]]; then
    CICD_PROJECT_FILE="$(basename "$PROJECT_PATH")"
    CICD_DEFAULT_SCHEME="${CICD_PROJECT_FILE%.xcodeproj}"
  elif [[ -n "$WORKSPACE_PATH" ]]; then
    CICD_PROJECT_FILE="$(basename "$WORKSPACE_PATH")"
    CICD_DEFAULT_SCHEME="${CICD_PROJECT_FILE%.xcworkspace}"
  fi
  CICD_TEST_DESTINATION="platform=iOS Simulator,name=iPhone 16"
  CICD_APP_IDENTIFIER="${FASTLANE_BUNDLE_IDENTIFIER:-com.example.app}"
fi

if [[ "$CICD_PLATFORM" == "android" ]]; then
  CICD_GRADLE_DIR="$(gradle_dir)"
  CICD_APP_IDENTIFIER="$(read_application_id "$CICD_GRADLE_DIR")"
  CICD_DEFAULT_SCHEME="app"
fi

case "$CICD_PLATFORM" in
  ios)
    CICD_RUNNER="macos-latest"
    CICD_FASTLANE_PLATFORM="ios"
    ;;
  android)
    CICD_RUNNER="ubuntu-latest"
    CICD_FASTLANE_PLATFORM="android"
    CICD_GRADLE_TASK="assembleDebug"
    ;;
  flutter)
  CICD_BUILD_TARGET="${CICD_BUILD_TARGET:-android}"
  if [[ "$CICD_BUILD_TARGET" == "ios" ]]; then
    CICD_RUNNER="macos-latest"
    CICD_FASTLANE_PLATFORM="flutter_ios"
  else
    CICD_RUNNER="ubuntu-latest"
    CICD_FASTLANE_PLATFORM="flutter_android"
  fi
  ;;
  react-native)
  CICD_BUILD_TARGET="${CICD_BUILD_TARGET:-android}"
  if [[ "$CICD_BUILD_TARGET" == "ios" ]]; then
    CICD_RUNNER="macos-latest"
    CICD_FASTLANE_PLATFORM="react_native_ios"
  else
    CICD_RUNNER="ubuntu-latest"
    CICD_FASTLANE_PLATFORM="react_native_android"
  fi
  ;;
esac

emit_human() {
  cat <<EOF
Detected platform: $CICD_PLATFORM
Runner: $CICD_RUNNER
App identifier: $CICD_APP_IDENTIFIER
EOF
  if [[ -n "$CICD_BUILD_TARGET" ]]; then
    echo "Build target: $CICD_BUILD_TARGET"
  fi
  if [[ -n "$CICD_PROJECT_FILE" ]]; then
    echo "Project file: $CICD_PROJECT_FILE"
  fi
  if [[ -n "$CICD_DEFAULT_SCHEME" ]]; then
    echo "Default scheme/module: $CICD_DEFAULT_SCHEME"
  fi
  if [[ -n "$CICD_GRADLE_DIR" ]]; then
    echo "Gradle directory: $CICD_GRADLE_DIR"
  fi
  if [[ -n "$CICD_TEST_DESTINATION" ]]; then
    echo "Test destination: $CICD_TEST_DESTINATION"
  fi
}

emit_env() {
  cat <<EOF
CICD_PLATFORM=$CICD_PLATFORM
CICD_RUNNER=$CICD_RUNNER
CICD_FASTLANE_PLATFORM=$CICD_FASTLANE_PLATFORM
CICD_APP_IDENTIFIER=$CICD_APP_IDENTIFIER
CICD_DEFAULT_CONFIGURATION=$CICD_DEFAULT_CONFIGURATION
CICD_GRADLE_TASK=$CICD_GRADLE_TASK
CICD_NODE_VERSION=$CICD_NODE_VERSION
EOF
  [[ -n "$CICD_BUILD_TARGET" ]] && echo "CICD_BUILD_TARGET=$CICD_BUILD_TARGET"
  [[ -n "$CICD_PROJECT_FILE" ]] && echo "CICD_PROJECT_FILE=$CICD_PROJECT_FILE"
  [[ -n "$CICD_DEFAULT_SCHEME" ]] && echo "CICD_DEFAULT_SCHEME=$CICD_DEFAULT_SCHEME"
  [[ -n "$CICD_TEST_DESTINATION" ]] && echo "CICD_TEST_DESTINATION=$CICD_TEST_DESTINATION"
  [[ -n "$CICD_GRADLE_DIR" ]] && echo "CICD_GRADLE_DIR=$CICD_GRADLE_DIR"
}

emit_github() {
  if [[ -z "${GITHUB_OUTPUT:-}" ]]; then
    echo "GITHUB_OUTPUT is not set" >&2
    exit 1
  fi
  {
    echo "platform=$CICD_PLATFORM"
    echo "runner=$CICD_RUNNER"
    echo "fastlane_platform=$CICD_FASTLANE_PLATFORM"
    echo "build_target=$CICD_BUILD_TARGET"
    echo "gradle_dir=$CICD_GRADLE_DIR"
    echo "gradle_task=$CICD_GRADLE_TASK"
  } >> "$GITHUB_OUTPUT"
}

emit_json() {
  python3 - <<PY
import json
print(json.dumps({
  "platform": "$CICD_PLATFORM",
  "runner": "$CICD_RUNNER",
  "fastlane_platform": "$CICD_FASTLANE_PLATFORM",
  "build_target": "$CICD_BUILD_TARGET",
  "project_file": "$CICD_PROJECT_FILE",
  "default_scheme": "$CICD_DEFAULT_SCHEME",
  "default_configuration": "$CICD_DEFAULT_CONFIGURATION",
  "test_destination": "$CICD_TEST_DESTINATION",
  "gradle_dir": "$CICD_GRADLE_DIR",
  "gradle_task": "$CICD_GRADLE_TASK",
  "app_identifier": "$CICD_APP_IDENTIFIER",
  "node_version": "$CICD_NODE_VERSION",
}))
PY
}

case "$FORMAT" in
  human) emit_human ;;
  env) emit_env ;;
  github) emit_github ;;
  json) emit_json ;;
  *)
    echo "Unsupported format: $FORMAT" >&2
    exit 1
    ;;
esac

if [[ "$CICD_PLATFORM" == "unknown" ]]; then
  exit 1
fi
