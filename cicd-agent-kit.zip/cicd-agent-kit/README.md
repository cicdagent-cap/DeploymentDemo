# CI/CD Agent Kit

Portable, multi-platform CI/CD agent for **iOS, Android, Flutter, and React Native**.

Copy or submodule this folder into your monorepo / agent orchestration repo and install it into any mobile project.

## Folder structure

```
cicd-agent-kit/
├── README.md                 # This file
├── INTEGRATION.md            # Full integration guide (keys, wiring, handoff)
├── manifest.yml              # Machine-readable inventory
├── install.sh                # Install kit into a target repo
│
├── agent/
│   └── CICD.agent.md         # Agent definition (register in Cursor / your orchestrator)
│
├── prompts/
│   ├── create-pipeline.prompt.md
│   └── trigger-build.prompt.md
│
├── config/
│   ├── cicd.config.yml       # Required keys per platform
│   ├── cicd.env.config.yml   # Default GitHub Variables
│   └── env.example           # Local env template
│
├── requests/                 # Request payloads other agents can fill
│   ├── pipeline-request.yml
│   └── trigger-build-request.yml
│
├── templates/
│   ├── mobile-ci-workflow.template.yml   # Primary (auto-detects platform)
│   └── ios-fastlane-workflow.template.yml # Legacy iOS-only
│
├── scripts/
│   ├── detect_project_platform.sh
│   ├── trigger_existing_workflow.sh
│   ├── inspect_workflow_inputs.sh
│   ├── notify.sh
│   ├── bootstrap_new_repo.sh
│   └── bootstrap_new_ios_repo.sh
│
├── fastlane/                 # Multi-platform Fastlane lanes
├── ruby/Gemfile
├── config-overrides/
└── docs/
    ├── HOT_RUN_SETUP.md
    └── AGENT_HANDOFF.md
```

## Quick install

From the repo that contains this kit:

```bash
chmod +x cicd-agent-kit/install.sh
./cicd-agent-kit/install.sh /path/to/mobile-repo [com.example.app]
```

## Quick verify

```bash
cd /path/to/mobile-repo
./scripts/detect_project_platform.sh
```

## Agent modes

| Mode | Purpose | Entry point |
|------|---------|-------------|
| **Create Pipeline** | Generate a GitHub Actions workflow | `prompts/create-pipeline.prompt.md` |
| **Trigger Build** | Run an existing workflow | `prompts/trigger-build.prompt.md` |

## Documentation

| Doc | Contents |
|-----|----------|
| [INTEGRATION.md](./INTEGRATION.md) | Keys, secrets, GitHub setup, multi-agent wiring |
| [docs/AGENT_HANDOFF.md](./docs/AGENT_HANDOFF.md) | Contracts for other agents (inputs/outputs) |
| [docs/HOT_RUN_SETUP.md](./docs/HOT_RUN_SETUP.md) | First-time onboarding checklist |

## Supported platforms

| Platform | Auto-detected by |
|----------|------------------|
| iOS | `.xcodeproj` / `.xcworkspace` |
| Android | Gradle (`android/` or root) |
| Flutter | `pubspec.yaml` + Flutter SDK |
| React Native | `package.json` + `react-native` |
