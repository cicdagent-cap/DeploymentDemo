#!/usr/bin/env bash
set -euo pipefail

usage() {
  cat <<'EOF'
Usage:
  ./cicd-agent-kit/install.sh <target-repo-path> [app-identifier]

Installs the CI/CD agent kit into a mobile project repository.

Examples:
  ./cicd-agent-kit/install.sh /Users/me/projects/MyApp com.example.myapp
  ./cicd-agent-kit/install.sh ../MyFlutterApp
EOF
}

TARGET_REPO="${1:-}"
APP_IDENTIFIER="${2:-}"

if [[ -z "$TARGET_REPO" ]]; then
  usage
  exit 1
fi

if [[ ! -d "$TARGET_REPO" ]]; then
  echo "Target path does not exist: $TARGET_REPO"
  exit 1
fi

KIT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET_REPO="$(cd "$TARGET_REPO" && pwd)"

copy_file() {
  mkdir -p "$(dirname "$2")"
  cp "$1" "$2"
}

chmod +x "$KIT_ROOT/scripts/detect_project_platform.sh"

DETECT_OUTPUT="$("$KIT_ROOT/scripts/detect_project_platform.sh" --repo "$TARGET_REPO" --format env)" || {
  echo "Could not detect a supported mobile project in: $TARGET_REPO"
  echo "Supported: iOS, Android, Flutter, React Native"
  exit 1
}

eval "$DETECT_OUTPUT"

if [[ -z "$APP_IDENTIFIER" || "$APP_IDENTIFIER" == "com.example.app" ]]; then
  APP_IDENTIFIER="$CICD_APP_IDENTIFIER"
fi

# --- Install kit files into standard repo layout ---
copy_file "$KIT_ROOT/agent/CICD.agent.md" "$TARGET_REPO/.github/agents/CICD.agent.md"
copy_file "$KIT_ROOT/prompts/create-pipeline.prompt.md" "$TARGET_REPO/.github/prompts/create-pipeline.prompt.md"
copy_file "$KIT_ROOT/prompts/trigger-build.prompt.md" "$TARGET_REPO/.github/prompts/trigger-build.prompt.md"
copy_file "$KIT_ROOT/templates/mobile-ci-workflow.template.yml" "$TARGET_REPO/.github/pipeline-templates/mobile-ci-workflow.template.yml"
copy_file "$KIT_ROOT/templates/ios-fastlane-workflow.template.yml" "$TARGET_REPO/.github/pipeline-templates/ios-fastlane-workflow.template.yml"
copy_file "$KIT_ROOT/config/cicd.config.yml" "$TARGET_REPO/.github/cicd.config.yml"
copy_file "$KIT_ROOT/config/cicd.env.config.yml" "$TARGET_REPO/.github/cicd.env.config.yml"
copy_file "$KIT_ROOT/requests/pipeline-request.yml" "$TARGET_REPO/.github/pipeline-request.yml"
copy_file "$KIT_ROOT/requests/trigger-build-request.yml" "$TARGET_REPO/.github/trigger-build-request.yml"
copy_file "$KIT_ROOT/config-overrides/config_overrides.json" "$TARGET_REPO/.github/config-overrides/config_overrides.json"

for script in detect_project_platform.sh trigger_existing_workflow.sh inspect_workflow_inputs.sh notify.sh bootstrap_new_repo.sh bootstrap_new_ios_repo.sh; do
  copy_file "$KIT_ROOT/scripts/$script" "$TARGET_REPO/scripts/$script"
  chmod +x "$TARGET_REPO/scripts/$script"
done

copy_file "$KIT_ROOT/ruby/Gemfile" "$TARGET_REPO/Gemfile"
copy_file "$KIT_ROOT/fastlane/Appfile" "$TARGET_REPO/fastlane/Appfile"
copy_file "$KIT_ROOT/fastlane/Fastfile" "$TARGET_REPO/fastlane/Fastfile"
copy_file "$KIT_ROOT/fastlane/Matchfile" "$TARGET_REPO/fastlane/Matchfile"
copy_file "$KIT_ROOT/fastlane/Pluginfile" "$TARGET_REPO/fastlane/Pluginfile"
copy_file "$KIT_ROOT/config/env.example" "$TARGET_REPO/.env.example"
copy_file "$KIT_ROOT/docs/HOT_RUN_SETUP.md" "$TARGET_REPO/CICD_HOT_RUN_SETUP.md"
copy_file "$KIT_ROOT/INTEGRATION.md" "$TARGET_REPO/CICD_INTEGRATION.md"

replace_in_file() {
  ruby -e 'path, old, newv = ARGV; c = File.read(path); c2 = c.gsub(old, newv); File.write(path, c2)' "$1" "$2" "$3"
}

case "$CICD_PLATFORM" in
  ios)
    replace_in_file "$TARGET_REPO/.github/cicd.env.config.yml" "DeploymentDemo.xcodeproj" "${CICD_PROJECT_FILE:-DeploymentDemo.xcodeproj}"
    replace_in_file "$TARGET_REPO/.github/cicd.env.config.yml" "DeploymentDemo" "${CICD_DEFAULT_SCHEME:-DeploymentDemo}"
    replace_in_file "$TARGET_REPO/.github/pipeline-templates/mobile-ci-workflow.template.yml" "__DEFAULT_PROJECT_FILE__" "${CICD_PROJECT_FILE:-DeploymentDemo.xcodeproj}"
    replace_in_file "$TARGET_REPO/.github/pipeline-templates/mobile-ci-workflow.template.yml" "__DEFAULT_SCHEME__" "${CICD_DEFAULT_SCHEME:-DeploymentDemo}"
    ;;
  android|flutter|react-native)
    replace_in_file "$TARGET_REPO/.github/cicd.env.config.yml" "DeploymentDemo" "${CICD_DEFAULT_SCHEME:-app}"
    ;;
esac

replace_in_file "$TARGET_REPO/.github/cicd.env.config.yml" "platform: ios" "platform: $CICD_PLATFORM"
replace_in_file "$TARGET_REPO/.github/cicd.env.config.yml" "CICD_PLATFORM: auto" "CICD_PLATFORM: $CICD_PLATFORM"
replace_in_file "$TARGET_REPO/.github/cicd.env.config.yml" "com.capgemini.DeploymentDemo" "$APP_IDENTIFIER"
replace_in_file "$TARGET_REPO/.env.example" "com.capgemini.DeploymentDemo" "$APP_IDENTIFIER"
replace_in_file "$TARGET_REPO/.env.example" "CICD_PLATFORM=auto" "CICD_PLATFORM=$CICD_PLATFORM"
replace_in_file "$TARGET_REPO/fastlane/Appfile" "com.capgemini.DeploymentDemo" "$APP_IDENTIFIER"

if [[ -n "${CICD_PROJECT_FILE:-}" ]]; then
  replace_in_file "$TARGET_REPO/.env.example" "CICD_PROJECT_FILE=DeploymentDemo.xcodeproj" "CICD_PROJECT_FILE=$CICD_PROJECT_FILE"
fi
if [[ -n "${CICD_DEFAULT_SCHEME:-}" ]]; then
  replace_in_file "$TARGET_REPO/.env.example" "CICD_DEFAULT_SCHEME=DeploymentDemo" "CICD_DEFAULT_SCHEME=$CICD_DEFAULT_SCHEME"
fi
if [[ -n "${CICD_TEST_DESTINATION:-}" ]]; then
  replace_in_file "$TARGET_REPO/.env.example" 'CICD_TEST_DESTINATION="platform=iOS Simulator,name=iPhone 16"' "CICD_TEST_DESTINATION=\"$CICD_TEST_DESTINATION\""
fi
if [[ -n "${CICD_BUILD_TARGET:-}" ]]; then
  replace_in_file "$TARGET_REPO/.env.example" "CICD_BUILD_TARGET=android" "CICD_BUILD_TARGET=$CICD_BUILD_TARGET"
fi
if [[ -n "${CICD_GRADLE_DIR:-}" ]]; then
  replace_in_file "$TARGET_REPO/.env.example" "CICD_GRADLE_DIR=android" "CICD_GRADLE_DIR=$CICD_GRADLE_DIR"
fi

echo "CI/CD agent kit installed"
echo "Target repo: $TARGET_REPO"
echo "Detected platform: $CICD_PLATFORM"
echo "App identifier: $APP_IDENTIFIER"
echo
echo "Next:"
echo "1) cp .env.example .notification.local.env"
echo "2) Configure secrets — see CICD_INTEGRATION.md"
echo "3) Register agent — see cicd-agent-kit/INTEGRATION.md"
