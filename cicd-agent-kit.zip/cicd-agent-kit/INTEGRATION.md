# CI/CD Agent — Integration Guide

Use this guide when wiring the CI/CD agent into a larger agent system (orchestrator, platform bot, release manager, etc.).

---

## 1. Overview

The CI/CD agent is a **specialist agent** with two capabilities:

1. **Create Pipeline** — generates a GitHub Actions workflow YAML from a template
2. **Trigger Build** — dispatches an existing GitHub Actions workflow and reports the run URL

It supports **iOS, Android, Flutter, and React Native** with automatic platform detection.

```
┌─────────────────┐     request YAML      ┌──────────────────┐
│  Orchestrator   │ ────────────────────► │   CI/CD Agent    │
│  (your agent)   │                       │                  │
└─────────────────┘ ◄──────────────────── └──────────────────┘
     run URL /                           scripts + templates
     workflow path
```

---

## 2. Installation into a target repo

### Option A — Install script (recommended)

```bash
./cicd-agent-kit/install.sh <absolute-path-to-mobile-repo> [app-identifier]
```

This copies all files into the standard layout under the target repo and auto-detects platform defaults.

### Option B — Copy kit into monorepo

Keep `cicd-agent-kit/` at a fixed path and point your orchestrator at:

- Agent definition: `cicd-agent-kit/agent/CICD.agent.md`
- Prompts: `cicd-agent-kit/prompts/`
- Install on demand via `install.sh`

### Option C — Register agent only (no install)

If the target repo already has CI/CD files, register the agent definition and prompts from this kit without running `install.sh`.

---

## 3. Registering with your agent system

### Cursor IDE

1. Copy or reference `agent/CICD.agent.md` into `.github/agents/CICD.agent.md` in the target repo (or register the kit path).
2. Copy prompts to `.github/prompts/`.
3. Invoke with agent name **CICD** and mode keywords:
   - `Create Pipeline`
   - `Trigger Build`

### Custom orchestrator

Register these metadata fields:

| Field | Value |
|-------|-------|
| `agent_id` | `cicd` |
| `capabilities` | `create-pipeline`, `trigger-build`, `detect-platform` |
| `definition` | `cicd-agent-kit/agent/CICD.agent.md` |
| `prompts.create_pipeline` | `cicd-agent-kit/prompts/create-pipeline.prompt.md` |
| `prompts.trigger_build` | `cicd-agent-kit/prompts/trigger-build.prompt.md` |

---

## 4. Handoff contracts (other agents → CI/CD agent)

Other agents pass work via **request files** or structured JSON with the same fields.

### 4a. Create Pipeline

**Request file:** `requests/pipeline-request.yml`

```yaml
pipeline:
  name: Release_Pipeline
  output_file: .github/workflows/release-pipeline.yml

platform:
  detection: auto          # or ios | android | flutter | react-native
  build_target: android    # for flutter / react-native

github_actions:
  runner_label: macos-latest
  default_branch: main

presets:
  default: Debug-CICD
```

**Expected output from CI/CD agent:**

- Generated workflow file at `output_file`
- Detected platform name
- List of missing secrets/variables for that platform

### 4b. Trigger Build

**Request file:** `requests/trigger-build-request.yml`

```yaml
target:
  workflow_url: https://github.com/org/repo/actions/workflows/ci.yml
  branch_name: main

workflow_inputs:
  preset: Debug-CICD
  Release_Notes: "Triggered by release agent"

notification:
  provider: teams
  webhook_secret_or_env_name: TEAM_WEBHOOK_URL
```

**Expected output from CI/CD agent:**

- `Build triggered successfully`
- `Run URL: https://github.com/.../actions/runs/<id>`
- Notification status (if webhook configured)

### 4c. Detect Platform (utility)

Any agent can call:

```bash
./scripts/detect_project_platform.sh --repo <path> --format json
```

**JSON response example:**

```json
{
  "platform": "flutter",
  "runner": "ubuntu-latest",
  "build_target": "android",
  "app_identifier": "com.example.app"
}
```

---

## 5. Required keys and secrets

### 5a. Always required (all platforms)

| Name | Type | Where | Purpose |
|------|------|-------|---------|
| `TEAM_WEBHOOK_URL` | Secret | GitHub Secrets + `.notification.local.env` | Teams/Slack notifications |
| `CICD_CHAT_PROVIDER` | Variable | GitHub Variables | `teams`, `slack`, or `generic` |
| `CICD_PLATFORM` | Variable | GitHub Variables | `auto` (default) or force platform |

**Local setup:**

```bash
cp .env.example .notification.local.env
# Fill TEAM_WEBHOOK_URL and CICD_CHAT_PROVIDER
```

### 5b. iOS

| Name | Type | Required for | Purpose |
|------|------|--------------|---------|
| `CICD_PROJECT_FILE` | Variable | Build | e.g. `MyApp.xcodeproj` |
| `CICD_DEFAULT_SCHEME` | Variable | Build | Xcode scheme name |
| `CICD_DEFAULT_CONFIGURATION` | Variable | Build | `Debug` / `Release` |
| `CICD_TEST_DESTINATION` | Variable | Tests | e.g. `platform=iOS Simulator,name=iPhone 16` |
| `FASTLANE_BUNDLE_IDENTIFIER` | Variable | Signing | Bundle ID |
| `FASTLANE_TEAM_ID` | Secret | Signing | Apple Developer Team ID |
| `FASTLANE_ITC_TEAM_ID` | Secret | App Store | App Store Connect Team ID |
| `MATCH_GIT_URL` | Secret | Signing | Match certificates repo |
| `MATCH_PASSWORD` | Secret | Signing | Match encryption password |
| `MATCH_GIT_BASIC_AUTHORIZATION` | Secret | Signing | Match repo auth (base64 `user:token`) |
| `APP_STORE_CONNECT_API_KEY` | Secret | TestFlight | ASC API key (`.p8` contents or JSON) |

### 5c. Android

| Name | Type | Required for | Purpose |
|------|------|--------------|---------|
| `CICD_GRADLE_DIR` | Variable | Build | `android` or `.` for root Gradle |
| `ANDROID_KEYSTORE_BASE64` | Secret | Release | Base64-encoded keystore file |
| `ANDROID_KEYSTORE_PASSWORD` | Secret | Release | Keystore password |
| `ANDROID_KEY_ALIAS` | Secret | Release | Key alias |
| `ANDROID_KEY_PASSWORD` | Secret | Release | Key password |

### 5d. Flutter

| Name | Type | Required for | Purpose |
|------|------|--------------|---------|
| `CICD_BUILD_TARGET` | Variable | Build | `android` (default) or `ios` |
| `CICD_GRADLE_DIR` | Variable | Android builds | Usually `android` |

Plus iOS secrets if `CICD_BUILD_TARGET=ios`, plus Android secrets for release Android builds.

### 5e. React Native

| Name | Type | Required for | Purpose |
|------|------|--------------|---------|
| `CICD_BUILD_TARGET` | Variable | Build | `android` or `ios` |
| `CICD_NODE_VERSION` | Variable | Build | e.g. `20` |
| `CICD_GRADLE_DIR` | Variable | Android builds | Usually `android` |

Plus platform-specific signing secrets as above.

### 5f. Optional (all platforms)

| Name | Type | Purpose |
|------|------|---------|
| `FIREBASE_APP_ID` | Secret | Firebase App Distribution |
| `FIREBASE_CLI_TOKEN` | Secret | Firebase CLI auth |
| `FIREBASE_GROUPS` | Variable | Tester groups |

---

## 6. GitHub Actions setup

**Path:** Repository → Settings → Secrets and variables → Actions

### Variables (repository level)

Set from `config/cicd.env.config.yml` after install, adjusted per project:

```
CICD_PLATFORM=auto
CICD_BUILD_TARGET=android
CICD_CHAT_PROVIDER=teams
CICD_PROJECT_FILE=...        # iOS
CICD_DEFAULT_SCHEME=...      # iOS
CICD_TEST_DESTINATION=...    # iOS
CICD_GRADLE_DIR=android      # Android / Flutter / RN
CICD_NODE_VERSION=20         # React Native
FASTLANE_BUNDLE_IDENTIFIER=...
```

### Secrets (repository level)

Minimum to get notifications working:

```
TEAM_WEBHOOK_URL
```

Add platform signing secrets before release builds (see section 5).

---

## 7. External tool requirements

| Tool | Used by | Required when |
|------|---------|---------------|
| [GitHub CLI (`gh`)](https://cli.github.com/) | `trigger_existing_workflow.sh` | Trigger Build mode |
| Ruby + Bundler | Fastlane | Pipeline runs with Fastlane |
| Xcode | iOS builds | iOS / Flutter-iOS / RN-iOS on macOS runner |
| Java 17 | Android builds | Android / Flutter / RN on Ubuntu |
| Flutter SDK | Flutter builds | Flutter projects |
| Node.js | React Native | RN projects |

**Auth for trigger script:**

```bash
gh auth login
gh auth status
```

---

## 8. Integration patterns

### Pattern A — Release agent triggers CI/CD agent

```
Release Agent                    CI/CD Agent
     │                                │
     │  fill trigger-build-request.yml │
     ├──────────────────────────────►│
     │                                │ inspect_workflow_inputs.sh
     │                                │ trigger_existing_workflow.sh
     │◄──────────────────────────────┤
     │  { run_url, status }           │
```

### Pattern B — Onboarding agent installs + creates pipeline

```
Onboarding Agent                 CI/CD Agent
     │                                │
     │  install.sh <new-repo>         │
     ├──────────────────────────────►│
     │                                │ detect_project_platform.sh
     │                                │ create pipeline from template
     │◄──────────────────────────────┤
     │  { workflow_path, platform,    │
     │    missing_secrets[] }         │
```

### Pattern C — Platform router dispatches by detection

```bash
PLATFORM=$(./scripts/detect_project_platform.sh --format json | jq -r .platform)

case "$PLATFORM" in
  ios)           invoke_agent cicd --mode create-pipeline --runner macos-latest ;;
  android)       invoke_agent cicd --mode create-pipeline --runner ubuntu-latest ;;
  flutter)       invoke_agent cicd --mode create-pipeline --build-target android ;;
  react-native)  invoke_agent cicd --mode create-pipeline --build-target android ;;
esac
```

---

## 9. Validation checklist

After integration, verify:

```bash
# 1. Platform detection
./scripts/detect_project_platform.sh

# 2. Local env
cp .env.example .notification.local.env
# fill TEAM_WEBHOOK_URL

# 3. Workflow inputs (after pipeline exists)
./scripts/inspect_workflow_inputs.sh <workflow-url> <branch>

# 4. Trigger
./scripts/trigger_existing_workflow.sh <workflow-url> <branch> preset=Debug-CICD
```

Expected: `Build triggered successfully` + run URL.

---

## 10. Troubleshooting

| Symptom | Fix |
|---------|-----|
| `Could not detect platform` | Ensure project has platform markers (xcodeproj, gradle, pubspec.yaml, etc.) |
| `Missing env setup` | Create `.notification.local.env` from `.env.example` |
| `gh: not authenticated` | Run `gh auth login` |
| iOS build fails on Ubuntu | Set `CICD_BUILD_TARGET=ios` and use macOS runner |
| Duplicate build skipped | `trigger_existing_workflow.sh` blocks if a run is already in progress |

---

## 11. File reference after install

| Installed path | Source in kit |
|----------------|---------------|
| `.github/agents/CICD.agent.md` | `agent/CICD.agent.md` |
| `.github/prompts/*.md` | `prompts/` |
| `.github/cicd.config.yml` | `config/cicd.config.yml` |
| `.github/pipeline-templates/*.yml` | `templates/` |
| `scripts/*.sh` | `scripts/` |
| `.env.example` | `config/env.example` |
| `CICD_INTEGRATION.md` | `INTEGRATION.md` (copy) |
| `CICD_HOT_RUN_SETUP.md` | `docs/HOT_RUN_SETUP.md` |

See `manifest.yml` for the complete inventory.
